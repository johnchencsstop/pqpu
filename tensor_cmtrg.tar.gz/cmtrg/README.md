# cmtrg
Corner Transfer Matrix Renormalization Group

This repository contains code for an implementation of the CMTRG algorithm on the 2D grid.
