import dmrg
import cProfile
cProfile.run(dmrg.main(100,4,4))
