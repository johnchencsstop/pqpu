# corner_transfer_renormalization_group

Performs corner transfer renormalization group for the two-d Ising model in the thermodynamic limit

My code is related to this paper but uses a different constrcution of the tensors

Corner Transfer Matrix Renormalization Group Method

T. Nishino, K. Okunishi
DOI:	10.1143/JPSJ.65.891
	arXiv:cond-mat/9507087

