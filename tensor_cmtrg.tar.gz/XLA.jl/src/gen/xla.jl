module xla
  const _ProtoBuf_Top_ = @static isdefined(parentmodule(@__MODULE__), :_ProtoBuf_Top_) ? (parentmodule(@__MODULE__))._ProtoBuf_Top_ : parentmodule(@__MODULE__)
  include("xla_data_pb.jl")
  include("hlo_pb.jl")
  include("xla_pb.jl")
end
