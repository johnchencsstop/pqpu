Files in this directory are generated using the `build.jl` script. Make
all changes to the originating docstrings/files rather than these ones.
Documentation should *only* be build directly on the `master` branch.
Source links would otherwise become unavailable should a branch be
deleted from the `origin`. This means potential pull request authors
*should not* run the build script when filing a PR.
