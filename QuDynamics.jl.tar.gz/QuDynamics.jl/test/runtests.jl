using QuBase
using QuDynamics
using Base.Test
using Compat

include("propagatortest.jl")
include("qutipinterfacetest.jl")
