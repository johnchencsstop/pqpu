module QuCmp

# package code goes here

end # module
