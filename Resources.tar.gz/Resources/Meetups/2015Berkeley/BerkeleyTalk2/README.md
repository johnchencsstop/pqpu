This repo includes the slides and two interactive examples of the talk given by David Zeng and Karanveer Mohan in the SQuInT 2015 breakout session -- Julia users meetup on Feb 21, 2015. 

The slides can be viewed in a web-browser through the [index.html](index.html). 

The interactive examples are written in [IPython notebooks](http://ipython.org/notebook.html) under the ***code*** directory: [time_series.ipynb](code/time_series.ipynb) and [Tomography.ipynb](code/Tomography.ipynb). 