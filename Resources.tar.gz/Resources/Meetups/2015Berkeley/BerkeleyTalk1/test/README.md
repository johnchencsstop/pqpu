# Testing

Current examples in this repository are just scripts, so at the moment we just run all the examples and verify that they execute successfully. 

In the future, if any examples use logic or modules, we will test them with Julia unit tests here.
