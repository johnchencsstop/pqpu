# Example Files

Each example file contains information about the problem.

## Contributing

The testing suite goes through and attempts to run every `.jl` file in this folder, so please put any dependencies in a nested folder. In addition, modules should be stored in a separate folder.
