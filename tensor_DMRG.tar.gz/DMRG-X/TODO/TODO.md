1. add dynamically resize the sparse matrix array,
this overcome the pre-define step that may meet segment fault 
2. write a manual
