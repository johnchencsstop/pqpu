export MKL_NUM_THREADS=1
mpirun  -np 2 /home/ren/DMRG-X/DMRG-X #: -np 1 -host mysmp /home/ren/DMRG-X/DMRG-X 
