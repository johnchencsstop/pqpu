#ifndef __DMTK_LANCZOS_H__
#define __DMTK_LANCZOS_H__

/*
void tqli(dmtk::Vector<double>& d, 
          dmtk::Vector<double>& e, 
          int n, dmtk::Matrix<double>& z, bool calc_vectors);

template<class A, class B>
void lanczos(A& m, B& gs, 
             const B& seed,
             double& e0, 
             dmtk::Vector<double>& a, dmtk::Vector<double>& b, 
             bool use_seed, bool calc_gs, const char *vectors_file);
*/

#endif // __DMTK_LANCZOS_H__
