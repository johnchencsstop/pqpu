python-dmrg
===========

Density Matrix Renormalization Group

Various DMRG algorithms.

Includes the Density Matrix Teaching Kit C++ source code.
