(* ::Package:: *)

bond=20;
length=60;
intrange=6;


outputfile="B20L60R6";
inputfile="B10L60R6"


\[Mu]ini=0.0;
\[Delta]\[Mu]=-0.1;
\[Mu]points=30;


Jini=0.0;
\[Delta]J=0.1;
Jpoints=20;
