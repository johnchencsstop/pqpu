# TEBD
A simple Time Evolving Block Decimation program

[![CodeFactor](https://www.codefactor.io/repository/github/aromanro/tebd/badge/master)](https://www.codefactor.io/repository/github/aromanro/tebd/overview/master)

Description is on https://compphys.go.ro/time-evolving-block-decimation/

For now only iTEBD is implemented.

### PROGRAM IN ACTION

[![Program video](https://img.youtube.com/vi/KHv_Tu7UIs8/0.jpg)](https://youtu.be/KHv_Tu7UIs8)
