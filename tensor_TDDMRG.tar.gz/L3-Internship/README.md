# L3-Internship
Implementation of the corner transfer matrix technique to obtain a lower bound on the entropy of some 2D-SFTs.
