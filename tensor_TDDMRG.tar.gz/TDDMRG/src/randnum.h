#ifndef randnum_h
#define randnum_h

#include "precision.h"

void  inline randnum_Set(void);
dreal inline randnum_Get(void);

#endif
