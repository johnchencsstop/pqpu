#ifndef constants_h
#define constants_h

#include "precision.h"

extern const int   MRET;
extern const dreal PI;
extern const dreal EV_HA;
extern const dreal HA_KBT;

#endif
