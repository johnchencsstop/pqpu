#ifndef tddmrg
#define tddmrg

void tddmrg_Init(void);
void tddmrg_Quit(void);
void tddmrg_Propagate(void);

#endif
